var myApp = angular.module('MyApp',[]);

myApp.controller('MobileCtrl', MobileCtrl);

MobileCtrl.$inject = ['MobileService', '$scope'];

function MobileCtrl(MobileService, $scope) {
  MobileService.getMobiles().then(function (resp) {
    $scope.mobiles =  resp;
  },function(badResp){
    console.info(badResp);
  });
}

function sort()
{
  alert("riya");
}
