angular.module('MyApp').factory('MobileService', function($http) {
    var mobileService = {};

    mobileService.getMobiles = function () {
        var a = $http.get("mobiles.json").then(function(response){
          return response.data;
        });
        return a;
    }
    return mobileService;
});
