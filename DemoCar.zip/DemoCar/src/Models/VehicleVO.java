package Models;

abstract public class VehicleVO {

	String make,model,engineCC;
	float fuelCap,mileage,price,roadTax;
	abstract public String getMake();
	abstract public void setMake(String make);
	abstract public String getModel() ;
		


	
	abstract public void setModel(String model);
		
	
	abstract public String getEngineCC();
	
	abstract public void setEngineCC(String engineCC);
	
	
	abstract public float getFuelCap();
	
	
	abstract public void setFuelCap(float fuelCap);

	
	abstract public float getMileage(); 
		
	
	abstract public void setMileage(float mileage); 
		
	
	abstract public float getPrice(); 
		
	
	abstract public void setPrice(float price); 
		
	
	abstract public float getRoadTax();
		
	abstract public void setRoadTax(float roadTax) ;
		
	
	}
	

