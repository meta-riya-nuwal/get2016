
package com.rest;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	 public class Connectiondatabase {

		private static Connectiondatabase jdbc;  
	    
	    //JDBCSingleton prevents the instantiation from any other class.  
	      private Connectiondatabase() {  }  
	       
	   
	        public static Connectiondatabase getInstance() {    
	                                    if (jdbc==null)  
	                                  {  
	                                           jdbc=new  Connectiondatabase();  
	                                  }  
	                        return jdbc;  
	            }  
	           
	  // to get the connection from methods like insert, view etc.   
	        protected Connection getConnection()throws ClassNotFoundException, SQLException  
	         {  
	               
	             Connection con=null;  
	             Class.forName("com.mysql.jdbc.Driver");  
	             con= DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "riya");  
	             return con;  
	               
	         }  
	}


