package com.rest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;




public class EmployeeDO {
      
	
	QueryClass queryClass=new QueryClass();
	Boolean insertEmployee(EmployeeVO emp)
	{
		String id=emp.getId();
		String name=emp.getName();
		int age=emp.getAge();
		int salary=emp.getSalary();
		String query="insert into employee values('"+id+"','"+name+"',"+age+","+salary+")";
		Boolean flag=queryClass.insertQuery(query);
		return flag;
	}
	ArrayList<EmployeeVO> getEmployeeById(String id)
	{
		ArrayList<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try
        {
			String query="select * from employee where id='"+id+"'";
			
		 ResultSet rs=queryClass.selectQuery(query);
        
           while (rs.next()) {
			EmployeeVO employee=new EmployeeVO();
		
			employee.setId(rs.getString(1));
			employee.setName(rs.getString(2));
			employee.setAge(rs.getInt(3));
			employee.setSalary(rs.getInt(4));
		   
			empList.add(employee);
			
		}
        }
        catch(SQLException e)
        {
        	System.out.println("Error in query");
        }
		return empList;
	}
	ArrayList<EmployeeVO> getEmployeeByName(String name)
	{
		ArrayList<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try
        {
			String query="select * from employee where name='"+name+"'";
			
		 ResultSet rs=queryClass.selectQuery(query);
        
           while (rs.next()) {
			EmployeeVO employee=new EmployeeVO();
		
			employee.setId(rs.getString(1));
			employee.setName(rs.getString(2));
			employee.setAge(rs.getInt(3));
			employee.setSalary(rs.getInt(4));
		   
			empList.add(employee);
			
		}
        }
        catch(SQLException e)
        {
        	System.out.println("Error in query");
        }
		return empList;
	}
	Boolean deleteEmployeeById(String id)
	{
		System.out.println("id id"+id);
		String query="delete from employee where id='"+id+"'";
		System.out.println(query);
		Boolean flag=queryClass.deleteQuery(query);
		return flag;
	}
	ArrayList<EmployeeVO> selectEmployee()
	
	{ArrayList<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try
        {
			String query="select * from employee";
			
		 ResultSet rs=queryClass.selectQuery(query);
        
           while (rs.next()) {
			EmployeeVO employee=new EmployeeVO();
		
			employee.setId(rs.getString(1));
			employee.setName(rs.getString(2));
			employee.setAge(rs.getInt(3));
			employee.setSalary(rs.getInt(4));
		   
			empList.add(employee);
			
		}
        }
        catch(SQLException e)
        {
        	System.out.println("Error in query");
        }
		return empList;
	}
	
}
