package com.rest;
import java.util.ArrayList;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("")
public class EmployeeService {

	  
		  @GET
		    @Path("/getEmployeeById")
		    @Produces(MediaType.APPLICATION_JSON)
		   
		    public Response getEmployeeById(@QueryParam("id") String id)
		   {

		       EmployeeDO emp=new EmployeeDO();
		     ArrayList<EmployeeVO>empList=  emp.getEmployeeById(id);
		     
		     GenericEntity<ArrayList<EmployeeVO>> generic = new GenericEntity<ArrayList<EmployeeVO>>(empList){};
		   //Sending the response
		    	   return Response.ok( generic ).build();
		       
		       

		    }
		  @GET
		    @Path("/getEmployeeByName")
		    @Produces(MediaType.APPLICATION_JSON)
		  public Response getEmployeeByName(@QueryParam("name") String name)
		   {

		       EmployeeDO emp=new EmployeeDO();
		     ArrayList<EmployeeVO>empList=  emp.getEmployeeByName(name);
		     GenericEntity<ArrayList<EmployeeVO>> generic = new GenericEntity<ArrayList<EmployeeVO>>(empList){};
		   //Sending the response
		    	   return  Response.ok( generic ).build();
		       
		       

		    }
		  @GET
		    @Path("/selectEmployee")
		    @Produces(MediaType.APPLICATION_JSON)
		  public Response selectEmployee()
		   {

		       EmployeeDO emp=new EmployeeDO();
		     ArrayList<EmployeeVO>empList=  emp.selectEmployee();
		     GenericEntity<ArrayList<EmployeeVO>> generic = new GenericEntity<ArrayList<EmployeeVO>>(empList){};
		   //Sending the response
		    	   return  Response.ok( generic ).build();
		       
		       

		    }
		  @DELETE
		    @Path("/deleteEmployeeById")
		    @Produces(MediaType.APPLICATION_JSON)
		  public String deleteEmployeeById(@QueryParam("id") String id)
		   {

		       EmployeeDO emp=new EmployeeDO();
		  Boolean flag=  emp.deleteEmployeeById(id);
                 
		   //Sending the response
		    	   if(flag==true)
		    		   return "Successful";
		    	   else
		    		   return "unsuccess";
		       
		       

		    }
		  @POST
		    @Path("/insertEmployee")
		    @Produces(MediaType.APPLICATION_JSON)
		  public String insertEmployee(EmployeeVO empVO)
		   {

		       EmployeeDO emp=new EmployeeDO();
		      
		  Boolean flag=  emp.insertEmployee(empVO);
		  if(flag==true)
   		   return "Successful";
   	   else
   		   return "unsuccess";
      
		 
		    	  
		       
		       

		    }
	  }

