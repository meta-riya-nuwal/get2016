package com.rest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;






public class QueryClass {
	Connectiondatabase jdbc;
	Connection con=null;

	public QueryClass()
	{
	
	 jdbc= Connectiondatabase.getInstance();  
	 try
		{
		 con=jdbc.getConnection();
		}
		catch(Exception e)
		{
			System.out.println("error in establishing connection");
		}
	}
	
	public ResultSet selectQuery(String query)
	{
		ResultSet rs=null;
		int i=0;
		try
		{
			System.out.println(con);
		PreparedStatement ps = con.prepareStatement(query);
		System.out.println(ps);
		 rs=ps.executeQuery();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return rs;
	}
	Boolean insertQuery(String query)
	{
		int flag=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		System.out.println(ps);
		 flag= ps.executeUpdate();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		if(flag>0)
			return true;
		else
			return false;
	}
	Boolean deleteQuery(String query)
	{
		int flag=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		
		 flag=ps.executeUpdate();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		if(flag>0)
			return true;
		else
			return false;
   
	}

	
}
