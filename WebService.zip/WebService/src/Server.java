import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class Server {
	@WebMethod
	public double convertFToC(double far){
		double cel = (far-32)*5/9;
		return cel;
	}
}
