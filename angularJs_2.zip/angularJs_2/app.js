var myApp = angular.module('MyApp',[]);

myApp.controller('customerCtrl', customerCtrl);
var customers=[];
customerCtrl.$inject = ['customerService', '$scope'];
function customerCtrl(customerService, $scope) {
  customerService.getCustomer().then(function (resp) {
    $scope.customers =  resp;
  },function(badResp){
    console.info(badResp);
  });
 $scope.limit=15;
 
 $scope.SetView=function(event){
	 if(event.target.id==="grid")
	 {
	
           $('.block').addClass('col-lg-3');
       } else {
           $('.block').removeClass('col-lg-3');
           
       }
 }

$scope.addCustomer=function(){
	
$scope.name;
$scope.email;
$scope.address;
$scope.orders;


   $scope.customers.push({
       Name:$scope.name,
	   address: $scope.address,
       NoOfOrders:$scope.orders,
	   Email: $scope.email
      });

}

$scope.deleteCustomer = function(item) {
 var index = $scope.customers.indexOf(item);
 $scope.customers.splice(index, 1);     
}
 
}

