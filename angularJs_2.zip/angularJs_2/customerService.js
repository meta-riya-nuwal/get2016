angular.module('MyApp').factory('customerService', function($http) {
    var customerService = {};

    customerService.getCustomer = function () {
        var a = $http.get("customers.json").then(function(response){
          return response.data;
        });
        return a;
    }
    return customerService;
});
